var searchData=
[
  ['mainscreen_0',['MainScreen',['../class_main_screen.html',1,'']]],
  ['mainwindow_1',['MainWindow',['../class_main_window.html',1,'']]]
];
