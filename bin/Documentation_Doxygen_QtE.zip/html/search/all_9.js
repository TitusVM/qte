var searchData=
[
  ['newaccount_0',['NewAccount',['../class_new_account.html',1,'NewAccount'],['../class_new_account.html#a47b7662c47db75d37bef8fcebbc49aad',1,'NewAccount::NewAccount()']]],
  ['newgame_1',['NewGame',['../class_new_game.html',1,'NewGame'],['../class_new_game.html#a47d8dc61292cdba16af9531a8d638814',1,'NewGame::NewGame()']]]
];
