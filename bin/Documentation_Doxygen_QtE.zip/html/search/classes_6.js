var searchData=
[
  ['newaccount_0',['NewAccount',['../class_new_account.html',1,'']]],
  ['newgame_1',['NewGame',['../class_new_game.html',1,'']]]
];
